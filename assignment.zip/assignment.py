import random

print('Welcome to addition:)')
print('Answer 5 questions in each stage')
print('Let us begin')
digitRange = 1
# the digit range starts at 1, which then increases in every loop
for d in range (1,5):
# d is an assigned variable for the outer loop, which repeats itself 4 times
    #print('Iteration for the Digit----------:', d)
    score = 0
    for q in range (1,6):
# q is an assigned variable for the inner loop which repeats itself 5 times
            #print('Inner Loop iteration:',q)
        randomVal =  random.randint(0,9)
        num1 = random.randint(1*digitRange,5*digitRange)
        num2 = random.randint(1*digitRange,4*digitRange)
#the reason for the numbers to be multiplied bu digit range is so that the numbers that needs to be added is increased
        print('What is', num1,'+' , num2,'=' )
        user_answer = int(input('Please enter your answer: ') )
        sum = num1 + num2
        if user_answer == sum:     
            print('GOOD JOB!')
            score +=1
        else:
            print('WRONG:(')
    print('Your score is',score)
    if score <= 3:
    #repeat 
        digitRange = digitRange * 10
# after the first loop is repeated the digit range will then multiply itself by 10 so that the number of digits to be added per loop is increased.
# and that it also stays under the limit of range. e.g. in loop 1, the digits that need to be added is 1 digit and the sum also needs to be one digit, so the max number of digits that can be added is 5+4 = 9
    print('-------------------------')